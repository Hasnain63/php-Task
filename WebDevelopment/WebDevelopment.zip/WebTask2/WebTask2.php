<?php
/* Q.1 Write program to show desired output as following */

/* Use all conditional operators between $a and $b to display following Output. 
TEST1 : Either a or b is false 
TEST2 : Either a or b is false 
TEST3 : Either a or b is true 
TEST4 : Either a or b is true 
TEST5 : a is true  
TEST6 : b is true  
TEST7 : a is false 
TEST8 : b is false */
function conditionalOperators() {
	$a = 42;  $b = 0;

	//TEST1 : Either a or b is false 
	if( $a && $b ) {            
		echo "TEST1 : Both a and b are true<br/>";
	}
	else {             
		echo "TEST1 : Either a or b is false<br/>";
	} 
	// TEST2 : Either a or b is false 
	$b= true;
	$a = true;
	if( $a && $b ) {            
		echo "TEST2 : Both a and b are true<br/>";
	}
	else {             
		echo "TEST3 : Either a or b is false<br/>";
	} 

	//TEST3 : Either a or b is true. Write Code for this condition


	//TEST4 : Either a or b is true . Write Code for this condition


	// TEST5 : a is true  . Write Code for this condition



	// TEST6 : b is true  . Write Code for this condition


	// TEST7 : a is false . Write Code for this condition


	
	// TEST8 : b is false. Write Code for this condition


	// your code is here
}


function numberInSingleLine () {
// your code is here
  $x = 0;$y = 1;$z = 2;$a = 3;
  echo $x;
}

function iterateVariables () {

   for ($x = 1; $x <= 10; $x++) {
    echo "The number is: $x <br>";
    if($x==4) {
    	continue;
    }
	// your code is here
   }
}

echo "<h1>Conditional If-Else Task:</h1>";
conditionalOperators();

echo "<h1>Print Numbers Task:</h1>";
numberInSingleLine();

echo "<h1>Loop base Task:</h1>";
iterateVariables();
?>