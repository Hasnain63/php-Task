<?php 
	if(isset($_SESSION['message'])) {
		echo "Congratulations! You are successfully logged in."
	}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Dashboard</title>
</head>
<body>
	<h1>Welcome to Dashboard</h1>
</body>
</html>
