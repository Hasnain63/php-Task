<!DOCTYPE html>
<html>
<head>
	<title>Submission Form</title>
</head>
<body>
	<?php 
	// write code to perform form submission and display validation errors


	?>
	
	
</body>
</html>