<!DOCTYPE html>
<html>
<head>
	<title>First Page</title>
</head>
<body>
	<?php $secondPageVar = "I am variable passed from First Page";
	// write code to echo $firstPageVar

	?>
	<a href="second_page.php">Move to Second Page</a>

	<form>
		<label>First Name:</label>
		<input type="text" name="first_name" id="first_name">
		<br>

		<label>Last Name:</label>
		<input type="text" name="first_name" id="first_name">
		<br>

		<label>Email Address:</label>
		<input type="email" name="first_name" id="first_name">
		<br>

		<label>Phone Number:</label>
		<input type="number" name="first_name" id="first_name">
		<br>
	</form>
</body>
</html>