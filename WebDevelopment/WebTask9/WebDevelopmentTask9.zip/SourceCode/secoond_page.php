<!DOCTYPE html>
<html>
<head>
	<title>Second Page</title>
</head>
<body>
	<?php $firstPageVar = "I am variable passed from Second Page";
	// write code to echo $secondPageVar from GET


	?>
	<a href="second_page.php">Move to Second Page</a>

	<?php
	// Write code to receieve data from POST

	?>
	
</body>
</html>